#!/bin/bash

cp SecureSignIn-4.0a-macOS /Applications/
echo "alias ssi='/Applications/SecureSignIn-4.0a-macOS'" >> ~/.bashrc
echo "alias ssi='/Applications/SecureSignIn-4.0a-macOS'" >> ~/.zshrc
